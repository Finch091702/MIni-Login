/**
 * Middleware para verificar si el usuario está autenticado
 * Si no está autenticado, lo redirige al login
 */
const isAuthenticated = (req, res, next) => {
  if (req.session && req.session.user) {
    // Regenerar ID de sesión periódicamente para evitar session fixation
    if (!req.session.lastRegenerated || 
        Date.now() - req.session.lastRegenerated > 15 * 60 * 1000) { // 15 minutos
      req.session.regenerate((err) => {
        if (err) {
          console.error('Error al regenerar sesión:', err);
          return res.status(500).render('error', { 
            message: 'Error de sesión', 
            error: { status: 500 } 
          });
        }
        req.session.user = res.locals.user; // Restaurar datos de usuario
        req.session.lastRegenerated = Date.now();
        next();
      });
    } else {
      // Actualizar timestamp de última actividad
      req.session.lastActivity = Date.now();
      next();
    }
  } else {
    res.redirect('/auth/login?error=not_authenticated');
  }
};

/**
 * Middleware para verificar si hay una sesión de inactividad
 * Cierra la sesión si ha pasado el tiempo máximo de inactividad
 */
const checkSessionExpiration = (req, res, next) => {
  if (req.session && req.session.user && req.session.lastActivity) {
    const inactiveTime = Date.now() - req.session.lastActivity;
    const maxInactiveTime = 30 * 60 * 1000; // 30 minutos
    
    if (inactiveTime > maxInactiveTime) {
      // La sesión ha expirado por inactividad
      req.session.destroy((err) => {
        if (err) {
          console.error('Error al destruir sesión expirada:', err);
        }
        return res.redirect('/auth/login?error=session_expired');
      });
    } else {
      next();
    }
  } else {
    next();
  }
};

/**
 * Middleware para verificar si el usuario ya está autenticado
 * Redirige al panel si ya tiene sesión iniciada
 */
const isNotAuthenticated = (req, res, next) => {
  if (req.session && req.session.user) {
    res.redirect('/panel');
  } else {
    next();
  }
};

/**
 * Middleware para verificar si el consentimiento de cookies ha sido dado
 */
const cookieConsentRequired = (req, res, next) => {
  if (req.cookies.cookiesAccepted === 'true') {
    next();
  } else {
    // Solo permitir continuar si es una ruta esencial
    const essentialRoutes = ['/auth/login', '/auth/register', '/legal/privacy', '/'];
    if (essentialRoutes.includes(req.path) || req.path.startsWith('/public')) {
      next();
    } else {
      res.redirect('/?consent_required=true');
    }
  }
};

module.exports = {
  isAuthenticated,
  isNotAuthenticated,
  checkSessionExpiration,
  cookieConsentRequired
};
