const { validationResult } = require('express-validator');
const User = require('../models/userModel');

/**
 * Controlador para registrar un nuevo usuario
 */
exports.register = async (req, res) => {
  try {
    // Validar campos de entrada
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).render('auth/register', {
        errors: errors.array(),
        oldInput: req.body
      });
    }

    const { email, password, name } = req.body;
    
    // Crear el usuario en la base de datos
    const user = await User.create({ email, password, name });
    
    // Iniciar sesión automáticamente después del registro
    req.session.regenerate((err) => {
      if (err) {
        console.error('Error al regenerar sesión:', err);
        return res.status(500).render('error', { 
          message: 'Error al iniciar sesión' 
        });
      }
      
      req.session.user = {
        id: user.id,
        email: user.email,
        name: user.name
      };
      req.session.lastActivity = Date.now();
      req.session.lastRegenerated = Date.now();
      
      res.redirect('/panel');
    });
  } catch (err) {
    if (err.message === 'El email ya está registrado') {
      return res.status(400).render('auth/register', {
        errors: [{ msg: err.message }],
        oldInput: req.body
      });
    }
    
    console.error('Error en el registro:', err);
    res.status(500).render('error', { 
      message: 'Error al registrar usuario' 
    });
  }
};

/**
 * Controlador para iniciar sesión
 */
exports.login = async (req, res) => {
  try {
    // Validar campos de entrada
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).render('auth/login', {
        errors: errors.array(),
        oldInput: { email: req.body.email }
      });
    }

    const { email, password, remember } = req.body;
    
    // Verificar credenciales
    const user = await User.verifyCredentials(email, password);
    
    if (!user) {
      return res.status(401).render('auth/login', {
        errors: [{ msg: 'Credenciales inválidas' }],
        oldInput: { email }
      });
    }
    
    // Regenerar la sesión para evitar session fixation
    req.session.regenerate((err) => {
      if (err) {
        console.error('Error al regenerar sesión:', err);
        return res.status(500).render('error', { 
          message: 'Error al iniciar sesión' 
        });
      }
      
      // Almacenar información del usuario en la sesión
      req.session.user = {
        id: user.id,
        email: user.email,
        name: user.name
      };
      req.session.lastActivity = Date.now();
      req.session.lastRegenerated = Date.now();
      
      // Si el usuario marcó "recuérdame", establecer una cookie
      if (remember) {
        // Cookie segura para "recordar" al usuario (solo almacena un identificador)
        res.cookie('rememberMe', user.id, {
          maxAge: 7 * 24 * 60 * 60 * 1000, // 1 semana
          httpOnly: true,
          secure: process.env.NODE_ENV === 'production',
          sameSite: 'strict'
        });
      }
      
      res.redirect('/panel');
    });
  } catch (err) {
    console.error('Error en el login:', err);
    res.status(500).render('error', { 
      message: 'Error al iniciar sesión' 
    });
  }
};

/**
 * Controlador para cerrar sesión
 */
exports.logout = (req, res) => {
  // Eliminar cookie de "recuérdame"
  res.clearCookie('rememberMe');
  
  // Destruir la sesión
  req.session.destroy((err) => {
    if (err) {
      console.error('Error al cerrar sesión:', err);
      return res.status(500).render('error', { 
        message: 'Error al cerrar sesión' 
      });
    }
    res.redirect('/auth/login');
  });
};

/**
 * Controlador para obtener el perfil del usuario
 */
exports.getProfile = async (req, res) => {
  try {
    const userId = req.session.user.id;
    const user = await User.findById(userId);
    
    if (!user) {
      return res.status(404).render('error', { 
        message: 'Usuario no encontrado' 
      });
    }
    
    res.render('panel/profile', { user });
  } catch (err) {
    console.error('Error al obtener perfil:', err);
    res.status(500).render('error', { 
      message: 'Error al cargar el perfil' 
    });
  }
};

/**
 * Controlador para actualizar preferencias del usuario
 */
exports.updatePreferences = async (req, res) => {
  try {
    const userId = req.session.user.id;
    const { darkMode, language } = req.body;
    
    await User.updatePreferences(userId, { 
      darkMode: darkMode === 'true' || darkMode === true, 
      language 
    });
    
    // Actualizar cookies de preferencias
    const cookieOptions = {
      maxAge: 365 * 24 * 60 * 60 * 1000, // 1 año
      httpOnly: false, // Permite acceso desde JS del cliente
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict'
    };
    
    res.cookie('darkMode', darkMode === 'true' || darkMode === true, cookieOptions);
    res.cookie('language', language, cookieOptions);
    
    res.redirect('/panel/settings');
  } catch (err) {
    console.error('Error al actualizar preferencias:', err);
    res.status(500).render('error', { 
      message: 'Error al actualizar preferencias' 
    });
  }
};

/**
 * Controlador para aceptar las cookies
 */
exports.acceptCookies = (req, res) => {
  // Establecer cookie de aceptación
  res.cookie('cookiesAccepted', 'true', {
    maxAge: 365 * 24 * 60 * 60 * 1000, // 1 año
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict'
  });
  
  res.redirect(req.query.redirect || '/');
};
