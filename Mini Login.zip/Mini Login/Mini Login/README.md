# MiPanel: Panel Personal Seguro para Usuarios

Sistema web demostrativo para ilustrar el manejo seguro de sesiones y cookies, incluyendo buenas prácticas, riesgos de seguridad y cumplimiento legal.

## 📋 Características

- **Autenticación Segura**: Sistema de login con manejo seguro de sesiones
- **Personalización**: Cookies para recordar preferencias (modo oscuro, idioma)
- **Seguridad Demostrada**: Ejemplos prácticos de riesgos y protecciones
- **Cumplimiento Legal**: Implementación de banner de cookies y políticas según GDPR

## 🔧 Tecnologías

- **Backend**: Node.js con Express
- **Gestión de Sesiones**: express-session
- **Frontend**: HTML, CSS, EJS como motor de plantillas
- **Base de datos**: SQLite (local)
- **Seguridad**: bcrypt para hash de contraseñas

## 🚀 Instalación

1. Clona este repositorio:
```
git clone https://github.com/tuusuario/mipanel.git
cd mipanel
```

2. Instala las dependencias:
```
npm install
```

3. Crea un archivo `.env` en la raíz del proyecto con el siguiente contenido:
```
PORT=3000
NODE_ENV=development
SESSION_SECRET=cambia_esto_en_produccion
DB_PATH=./data/mipanel.db
```

4. Inicia la aplicación:
```
npm run dev
```

5. Visita `http://localhost:3000` en tu navegador

## 📊 Estructura del Proyecto

```
/mipanel
├── /public           # Archivos estáticos (CSS, imágenes)
├── /views            # Plantillas EJS
├── /routes           # Enrutadores Express
├── /middlewares      # Middleware personalizado
├── /controllers      # Controladores
├── /models           # Modelos de datos
├── /config           # Configuraciones
├── /data             # Base de datos SQLite
├── app.js            # Punto de entrada principal
├── package.json
└── README.md
```

## 🔐 Demostraciones de Seguridad

El proyecto incluye demostraciones educativas de:

- Vulnerabilidades cuando no se usa HttpOnly en cookies sensibles
- Simulación de ataques de session hijacking
- Regeneración de ID de sesión y su importancia
- Expiración automática de sesiones por inactividad

## 📜 Aspectos Legales

El proyecto implementa:

- Banner de consentimiento de cookies
- Políticas de privacidad y cookies detalladas
- Cumplimiento con GDPR/RGPD
- No almacenamiento de cookies no esenciales hasta obtener consentimiento

## 👥 Contribuciones

Las contribuciones son bienvenidas. Por favor, abre un issue primero para discutir lo que te gustaría cambiar o mejorar.

## 📄 Licencia

Este proyecto está licenciado bajo la Licencia ISC - vea el archivo LICENSE para más detalles.
