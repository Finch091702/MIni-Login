const db = require('../config/db');
const bcrypt = require('bcrypt');

class User {
  /**
   * Crear un nuevo usuario
   * @param {Object} userData - Datos del usuario (email, password, name)
   * @returns {Promise} - Promesa con el resultado de la operación
   */
  static async create(userData) {
    const { email, password, name } = userData;
    
    try {
      // Encriptar la contraseña antes de guardarla
      const hashedPassword = await bcrypt.hash(password, 10);
      
      return new Promise((resolve, reject) => {
        const sql = `INSERT INTO users (email, password, name) VALUES (?, ?, ?)`;
        
        db.run(sql, [email, hashedPassword, name], function(err) {
          if (err) {
            if (err.message.includes('UNIQUE constraint failed')) {
              return reject(new Error('El email ya está registrado'));
            }
            return reject(err);
          }
          
          // Insertar preferencias por defecto
          const prefSql = `INSERT INTO user_preferences (user_id) VALUES (?)`;
          db.run(prefSql, [this.lastID], (err) => {
            if (err) return reject(err);
            resolve({ id: this.lastID, email, name });
          });
        });
      });
    } catch (err) {
      throw err;
    }
  }

  /**
   * Buscar un usuario por su email
   * @param {string} email - Email del usuario
   * @returns {Promise} - Promesa con el usuario encontrado o null
   */
  static findByEmail(email) {
    return new Promise((resolve, reject) => {
      const sql = `SELECT * FROM users WHERE email = ?`;
      
      db.get(sql, [email], (err, user) => {
        if (err) return reject(err);
        resolve(user || null);
      });
    });
  }

  /**
   * Buscar un usuario por su ID
   * @param {number} id - ID del usuario
   * @returns {Promise} - Promesa con el usuario encontrado o null
   */
  static findById(id) {
    return new Promise((resolve, reject) => {
      const sql = `
        SELECT u.*, p.dark_mode, p.language 
        FROM users u
        LEFT JOIN user_preferences p ON u.id = p.user_id
        WHERE u.id = ?
      `;
      
      db.get(sql, [id], (err, user) => {
        if (err) return reject(err);
        if (user) {
          // Eliminar la contraseña de los datos devueltos por seguridad
          delete user.password;
        }
        resolve(user || null);
      });
    });
  }

  /**
   * Verificar las credenciales de un usuario
   * @param {string} email - Email del usuario
   * @param {string} password - Contraseña en texto plano
   * @returns {Promise} - Promesa con el usuario si las credenciales son correctas, o null
   */
  static async verifyCredentials(email, password) {
    try {
      const user = await this.findByEmail(email);
      if (!user) return null;
      
      const passwordMatch = await bcrypt.compare(password, user.password);
      if (!passwordMatch) return null;
      
      // Eliminar la contraseña de los datos devueltos por seguridad
      delete user.password;
      return user;
    } catch (err) {
      throw err;
    }
  }

  /**
   * Actualizar las preferencias de un usuario
   * @param {number} userId - ID del usuario
   * @param {Object} preferences - Preferencias a actualizar
   * @returns {Promise} - Promesa con el resultado de la operación
   */
  static updatePreferences(userId, preferences) {
    return new Promise((resolve, reject) => {
      const { darkMode, language } = preferences;
      const sql = `
        UPDATE user_preferences 
        SET dark_mode = ?, language = ?
        WHERE user_id = ?
      `;
      
      db.run(sql, [darkMode ? 1 : 0, language, userId], function(err) {
        if (err) return reject(err);
        resolve({ darkMode, language, userId });
      });
    });
  }
}

module.exports = User;
