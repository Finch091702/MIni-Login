/**
 * Script principal para el sitio MiPanel
 * Maneja funcionalidades comunes como el banner de cookies
 */

document.addEventListener('DOMContentLoaded', function() {
  // Banner de cookies
  const cookieBanner = document.getElementById('cookie-banner');
  const acceptCookiesBtn = document.getElementById('accept-cookies');
  
  if (cookieBanner && acceptCookiesBtn) {
    acceptCookiesBtn.addEventListener('click', function() {
      // Redireccionar a la ruta que establece la cookie de aceptación
      const currentUrl = encodeURIComponent(window.location.pathname);
      window.location.href = `/settings/accept-cookies?redirect=${currentUrl}`;
    });
  }
  
  // Detección de preferencia de tema del sistema para usuarios nuevos
  if (!document.cookie.includes('darkMode')) {
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    if (prefersDarkScheme.matches) {
      document.body.classList.add('dark-mode');
    }
  }
});
