/**
 * Script para el panel de control
 * Maneja las interacciones del usuario dentro del panel
 */

document.addEventListener('DOMContentLoaded', function() {
  // Activar elementos de menú según la URL actual
  const currentPath = window.location.pathname;
  const menuItems = document.querySelectorAll('.sidebar-menu li');
  
  menuItems.forEach(item => {
    const link = item.querySelector('a');
    if (link && currentPath.includes(link.getAttribute('href'))) {
      item.classList.add('active');
    }
  });
  
  // Conmutar tema oscuro desde la interfaz
  const darkModeToggle = document.getElementById('dark-mode-toggle');
  if (darkModeToggle) {
    darkModeToggle.addEventListener('change', function() {
      // Cambiar la clase del body inmediatamente para feedback visual
      document.body.classList.toggle('dark-mode', this.checked);
      
      // Enviamos la preferencia al servidor mediante AJAX para que actualice la cookie
      fetch('/settings/preferences', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `darkMode=${this.checked}&language=${document.getElementById('language-selector').value}`
      });
    });
  }
  
  // Cambiar idioma desde la interfaz
  const languageSelector = document.getElementById('language-selector');
  if (languageSelector) {
    languageSelector.addEventListener('change', function() {
      // Enviamos la preferencia al servidor mediante AJAX
      fetch('/settings/preferences', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `darkMode=${document.getElementById('dark-mode-toggle').checked}&language=${this.value}`
      }).then(() => {
        // Recargamos la página para que refleje el nuevo idioma
        window.location.reload();
      });
    });
  }
  
  // Timer de inactividad para la sesión
  let inactivityTimer;
  const maxInactiveTime = 30 * 60 * 1000; // 30 minutos (debe coincidir con la configuración del servidor)
  
  function resetInactivityTimer() {
    clearTimeout(inactivityTimer);
    inactivityTimer = setTimeout(function() {
      alert('Tu sesión está a punto de expirar por inactividad');
      // Redirigir al login después de mostrar el alert
      window.location.href = '/auth/logout';
    }, maxInactiveTime - 60000); // Avisar 1 minuto antes
  }
  
  // Reiniciar timer en cada interacción del usuario
  ['click', 'touchstart', 'mousemove', 'keypress'].forEach(event => {
    document.addEventListener(event, resetInactivityTimer);
  });
  
  // Iniciar el timer cuando se carga la página
  resetInactivityTimer();
});
