require('dotenv').config();
const express = require('express');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const path = require('path');
const db = require('./config/db');

// Importación de rutas
const authRoutes = require('./routes/auth');
const panelRoutes = require('./routes/panel');
const settingsRoutes = require('./routes/settings');
const legalRoutes = require('./routes/legal');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware para procesar JSON y datos de formularios
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Configuración de la carpeta pública para archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Configuración del motor de vistas EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Configuración de sesiones seguras
app.use(session({
  secret: process.env.SESSION_SECRET || 'mipanel_secret_key',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production', // true en producción (HTTPS)
    httpOnly: true, // Evita acceso desde JavaScript del cliente
    maxAge: 30 * 60 * 1000, // 30 minutos de inactividad
    sameSite: 'strict' // Protección contra CSRF
  }
}));

// Middleware para verificar cookies de consentimiento
app.use((req, res, next) => {
  res.locals.cookiesAccepted = req.cookies.cookiesAccepted === 'true';
  res.locals.darkMode = req.cookies.darkMode === 'true';
  res.locals.language = req.cookies.language || 'es';
  res.locals.user = req.session.user || null;
  next();
});

// Rutas
app.use('/auth', authRoutes);
app.use('/panel', panelRoutes);
app.use('/settings', settingsRoutes);
app.use('/legal', legalRoutes);

// Ruta principal
app.get('/', (req, res) => {
  res.render('index');
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
});

// Manejo de errores global
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', { 
    message: 'Ha ocurrido un error en el servidor',
    error: process.env.NODE_ENV === 'development' ? err : {}
  });
});
