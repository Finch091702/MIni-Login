const express = require('express');
const userController = require('../controllers/userController');
const { isAuthenticated, checkSessionExpiration } = require('../middlewares/authMiddleware');

const router = express.Router();

// Aplicar middleware de autenticación a todas las rutas del panel
router.use(checkSessionExpiration);
router.use(isAuthenticated);

// Ruta principal del panel
router.get('/', (req, res) => {
  res.render('panel/dashboard', {
    user: req.session.user
  });
});

// Ruta de perfil
router.get('/profile', userController.getProfile);

// Ruta de configuraciones
router.get('/settings', (req, res) => {
  res.render('panel/settings', {
    user: req.session.user,
    darkMode: req.cookies.darkMode === 'true',
    language: req.cookies.language || 'es'
  });
});

// Ruta para mostrar ejemplos de seguridad
router.get('/security-demo', (req, res) => {
  // Crear una cookie insegura para demostración
  res.cookie('insecureCookie', 'valorSensible', {
    maxAge: 5 * 60 * 1000, // 5 minutos
    httpOnly: false, // Demostración de inseguridad: accesible desde JS
    secure: false,
    sameSite: 'lax'
  });
  
  res.render('panel/security-demo', {
    user: req.session.user
  });
});

module.exports = router;
