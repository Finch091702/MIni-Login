const express = require('express');
const { body } = require('express-validator');
const userController = require('../controllers/userController');
const { isNotAuthenticated } = require('../middlewares/authMiddleware');

const router = express.Router();

// Validaciones para el registro
const registerValidation = [
  body('name').trim().notEmpty().withMessage('El nombre es obligatorio'),
  body('email')
    .isEmail().withMessage('Email inválido')
    .normalizeEmail(),
  body('password')
    .isLength({ min: 6 }).withMessage('La contraseña debe tener al menos 6 caracteres')
    .matches(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).*$/).withMessage('La contraseña debe incluir al menos una letra mayúscula, una minúscula y un número'),
  body('passwordConfirm')
    .custom((value, { req }) => {
      if (value !== req.body.password) {
        throw new Error('Las contraseñas no coinciden');
      }
      return true;
    })
];

// Validaciones para el login
const loginValidation = [
  body('email')
    .isEmail().withMessage('Email inválido')
    .normalizeEmail(),
  body('password').notEmpty().withMessage('La contraseña es obligatoria')
];

// Rutas de autenticación
router.get('/register', isNotAuthenticated, (req, res) => {
  res.render('auth/register', {
    errors: [],
    oldInput: {}
  });
});

router.post('/register', isNotAuthenticated, registerValidation, userController.register);

router.get('/login', isNotAuthenticated, (req, res) => {
  res.render('auth/login', {
    errors: req.query.error ? [{ msg: 'Debes iniciar sesión para continuar' }] : [],
    oldInput: {}
  });
});

router.post('/login', isNotAuthenticated, loginValidation, userController.login);

router.get('/logout', userController.logout);

module.exports = router;
