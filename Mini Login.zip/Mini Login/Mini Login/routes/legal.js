const express = require('express');
const router = express.Router();

// Página de política de privacidad
router.get('/privacy', (req, res) => {
  res.render('legal/privacy');
});

// Página de términos y condiciones
router.get('/terms', (req, res) => {
  res.render('legal/terms');
});

// Página de política de cookies
router.get('/cookies', (req, res) => {
  res.render('legal/cookies');
});

module.exports = router;
