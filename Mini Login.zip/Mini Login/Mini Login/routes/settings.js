const express = require('express');
const userController = require('../controllers/userController');
const { isAuthenticated } = require('../middlewares/authMiddleware');

const router = express.Router();

// Aplicar middleware de autenticación a todas las rutas de configuración
router.use(isAuthenticated);

// Actualizar preferencias del usuario
router.post('/preferences', userController.updatePreferences);

// Aceptar cookies desde las configuraciones
router.get('/accept-cookies', userController.acceptCookies);

module.exports = router;
